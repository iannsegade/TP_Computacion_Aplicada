
if [ "$1" == "-help" ] || [ -z "$1" ] || [ -z "$2" ]; then
	echo "Uso: $0 <origen> <destino>"
	echo "Ejemplo: $0 /var/log /backup_dir"
	exit 0
fi

ORIGEN=$1
DESTINO=$2

if [ ! -d "$ORIGEN" ] || [ ! -d "$DESTINO" ]; then
	echo "Error: El origen o el destino no estan disponibles."
	exit 1
fi

FECHA=$(date +%Y%m%d)
NOMBRE_CARPETA=$(basename "$ORIGEN")
ARCHIVO="${NOMBRE_CARPETA}_bkp_${FECHA}.tar.gz"

tar -czf "$DESTINO/$ARCHIVO" -C "$(dirname "$ORIGEN")" "$NOMBRE_CARPETA"

echo "Backup de $NOMBRE_CARPETA guardado en $DESTINO."
