history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
apt update && apt install sudo -y
sudo nano /etc/apt/sources.list
clear
nano /etc/apt/sources.list
clear
vi /etc/apt/sources.list
vi /etc/apt/sources.list
clear
apt update
ip link set eth0 down
ip link set eno0s3 down
ip link show
ip link set enp0s3 up
dhclient enp0s3
apt update
clear
vi /etc/apt/sources.list
apt update
vi /etc/apt/soruces.list
vi /etc/apt/sources.list
apt update
apt full-upgrade
clear
cat etc/os-release
clear
cat /etc/os-release
clear
apt install openssh-server
/etc/ssh
clear
/etc/bash
clear
etc/ssh
clear
/etc/ssh
systemctl enable ssh
systemctl start ssh
clear
vi /etc/ssh/sshd_config
clear
vim /etc/ssh/sshd_config
clear
systemctl restart ssh
ssh-keygen
clear
apt install apache2 libapache2-mod-php php -y
clear
systemctl start apache2
sytemctl enable apache2
clear
systemctl start apache2
systemctl enable apache2
cp /root/index.php /var/www/html/
clear
echo "PHP funciona" > /var/www/html/index.php
touch /var/www/html/logo.png
rm /var/www/html/index.html
curl http://localhost/index.php
clear
curl http://localhost/index.php
curl http://localhost/index.php
shutdown -h now
clear
hostnamectl set-hostname TPServer
hostname
sudo 
clear
sudo nano /etc/apt/sources.list
su -
ls -la /root/.shsh/
..
cd ..
ls -la /root/.ssh/
rm /root/.ssh/id_rsa
rm /root/.ssh/id_rsa.pub
ls -la /root/.ssh/
shutdown -h now
ls /media/
ls /media/cdrom
ls /media/cdrom0
ls /me
shutdown -h now
who
exit
ls -l /media
mkdir -p /media/compartida
mount -t vboxsf compartida /media/compartida
ls -l /media/compartida
mkdir -p /root/mis_archivos
cp -r /media/compartida/* /root/mis_archivos/
ls -la /root/mis_archivos/
clear
mkdir -p /root/.ssh
chmod 700 /root/.ssh
clear
cat /root/mis_archivos/clave_publica.pub /root/.ssh/authorized_keys
clear
cat /root/mis_archivos/clave_publica.pub >> /root/.ssh/authorized_keys
chmod  600 /root/.ssh/authorized_keys
cp /root/mis_archivos/clave_privada.txt /root/.ssh/
chmod 600 /root/.ssh/clave_privada.txt
ssh -i /root/.ssh/clave_privada.txt -l root localhost
clear
rm -rf /var/www/html/*
shutdown -h now
clear
ls -la /root/media/
cd ..
ls -la /root/media/
ls -la /media
ls -la /media/compartida
umount /media/compartida
mount -t vboxsf compartida /media/compartida
ls -la /media/compartida
clear
cp /media/compartida/logo.png /root/mis_archivos/
clear
cp /root/mis_archivos/index.php /var/www/html/
cp /root/mis_archivos/index.php /var/www/html/
clear
chown -R www-dataa:www-dataa /var/www/html/
clear
chown -R www-data:www-data /var/www/html/
chmod -R 755 /var/www/html/
systemctl restart apache2
clear
curl http://localhost/index.php
exit
clear
curl -l http://localhost/index.php
clear
curl -I http://localhost/index.php
tail -n 20 /var/log/apache2/error.log
clear
apt install mariadb-server -y
clear
systemctl start mariadb
systemctl enable mariadb
clear
mariadb -e "CREATE DATABASE IF NOT EXISTS ingenieria;"
maria db ingenieria < /root/mis_arhivos/db.sql
ls -l /root/mis_archivos/
clear
mariadb -e "DROP DATABASE ingenieria;"
clear
mariadb < /root/mis_archivos/db.sql
curl http://localhost/index.php
tail -n 20 /var/log/apache2/error.log
clear
apt install php-mysql -y
clear
phpenmod mysqli
systemctl stop apache2
systemctl start apache2
clear
php -m | grep mysqli
clear
curl http://localhost/index.php
clear
ip a
poweroff
clear
ip a
grep -i "img src" /var/www/html/index.php
cp /root/mis_archivos/logo.png /var/www/html/logo.png
chown www-data:www-data /var/www/html/logo.png
chmod 644 /var/www/html/logo.png
clear
poweroff
clear
vi /etc/network/interfaces
clear
ip -4 a
ip route
clear
vi /etc/network/interfaces
clear
vi /etc/network/interfaces
clear
poweroff
systemctl restart networking
ip a
poweroff
clear
fdisk /dev/sdb
poweroff
clear
fdisk /dev/sdc
clear
lsblk
clear
fdisk /dev/sdb
umount /dev/sdb* 2>/dev/null
wipefs -a /dev/sdb
clear
fdisk /dev/sdb
clear
fdisk /dev/sdb
clear
mkfs.ext4 /dev/sdb1
mkfs.ext4 /dev/sdb2
clear
mkdir /www_dir
mkdir /backup_dir
mount /dev/sdb1 /www_dir
clear
cp /var/www/html/index.php /www_dir/
cp /var/www/html/logo.png /www_dir/
chown -R www-data:www-data /www_dir
clear
vi /etc/apache2/sites-available/000-default.conf
clear
systemctl restart apache2
curl -I http://localhost/index.php
chown -R www-data:www-data /www_dir
chmod 755 /www_dir
chmod 644 /www_dir/index.php
chmod /www_dir/logo.png
ls -l /www_dir
chmod 644 /www
clear
chmod 644 /www_dir/logo.png
clear
curl -I http://localhost/index.php
clear
vi /etc/apache2/apache2.conf
clear
systemctl restart apache2
curl -I http://localhost/index.php
cat /www_dir/index.php
clear
chmod -R 777 /www_dir
vi /etc/apache2/sites-available/000-default.conf
cleeear
clear
curl -I http://localhost/index.php
vi /etc/apache2/sites-available/000-default.conf
clear
systemctl restart apache2
clear
systemctl restart apache2
vi /etc/apache2/sites-available/000-default.conf
clear
systemctl restart apache2
vi /etc/apache2/sites-available/000-default.conf
clear
systemctl restart apache2
curl -I http://localhost/index.php
poweroff
clear
blkid /dev/sdb1
vi /etc/fstab
clear
umount /www_dir
mount -a
vi /etc/fstab
clear
umount /www_dir
mount -a
systemctl deamon-reload
systemctl daemon-reload
clear
mount -a
clear
umount /www_dir
mount -a
df -h
clear
umount /dev/sdb1
systemctl daemon-reload
mount -a
df -h
clear
mkdir -p /www_dir
clear
umount -l /dev/sdb1
systemctl daemon-reload
mount -a
df -h
reboot
clear
df -h
clear
umont -l /dev/sdb1
clear
umount -l /dev/sdb1
systemctl daemon-reload
mount -a
df -h
clear
mkdir -p /backup_dir
clear
clear
blkid /dev/sdb2
clear
vi /etc/fstab
clear
systemctl daemon-reload
mount -a
clear
vi /etc/stab
clear
vi /etc/fstab
clear
umount -l /dev/sdb2
systemctl daemon-reload
mount -a
partprobe /dev/sdb
reboot
mount -o remount,rw /
vi /etc/fstab
clear
vi /etc/fstab
clear
reboot
poweroff
clear
vi /etc/fstab
cclear
clear
systemctl daemon-reload
mount -a
df -h
clear
cat /proc/partitions > /opt/particion
cat /opt/particion
reboot
